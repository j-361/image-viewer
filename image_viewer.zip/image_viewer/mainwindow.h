#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPixmap>
#include <QMovie>


QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_actionApri_triggered();

    void on_actionSlideshow_triggered();

    void on_actionChiudi_triggered();

    void on_actionEsci_triggered();

    void on_actionZoom_Avanti_triggered();

    void on_actionZoom_Indietro_triggered();

    void on_actionZoom_1_1_triggered();

    void on_actionStart_triggered();

    void on_actionStop_triggered();

    void on_actionPausa_triggered(bool checked);

    void on_actionAumenta_triggered();

    void on_actionDiminuisci_triggered();

    void on_actionNormale_triggered();

private:
    Ui::MainWindow *ui;

    QPixmap _pixmap;
    QMovie *_movie;

    int _originalWidth;
    int _originalHeight;
};
#endif // MAINWINDOW_H
