#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QFileDialog>
#include <QFileInfo>
#include <QMessageBox>
#include <QStandardPaths>
#include <QDir>
#include <QStringList>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowTitle("Visualizzatore immagini");

    _pixmap = QPixmap();
    _movie = nullptr;

    _originalWidth = 0;
    _originalHeight = 0;
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_actionApri_triggered()
{
    QString path = QFileDialog::getOpenFileName(this);
    if (path.isEmpty())
        return;

    QFileInfo info(path);
    if (info.suffix() == "gif")
    {
        if (_movie != nullptr)
        {
            delete _movie;
            _movie = nullptr;
        }
        _movie = new QMovie(path);
        ui->label->setMovie(_movie);
        _movie->start();
        return;
    }
    _pixmap = QPixmap(path);
    ui->label->setPixmap(_pixmap);

    _originalWidth = _pixmap.width();
    _originalHeight = _pixmap.height();
}

void MainWindow::on_actionSlideshow_triggered()
{
    QString testo = "";
    QString path = QFileDialog::getExistingDirectoryUrl(this, "Seleziona cartella").toString();
    QDir directory(path);

    QStringList files = directory.entryList();

    for(int i = 0; i < files.length(); i++)
    {
        testo += files.at(i);
    }

    ui->label->setText(testo);
}

void MainWindow::on_actionChiudi_triggered()
{
    ui->label->setText("Seleziona un'immagine da visualizzare");
    _pixmap = QPixmap(0, 0); //creo una pixmap nulla
    _movie = nullptr;
}

void MainWindow::on_actionEsci_triggered()
{
    close();
}

void MainWindow::on_actionZoom_Avanti_triggered()
{
    if(_pixmap.width() == 0 || _pixmap.height() == 0)
    {
        QMessageBox::warning(this, tr("Attenzione"), tr("Non è stata selezionata alcuna immagine adatta alla zoom"));
        return;
    }

    int newWidth = _pixmap.width()*110/100;
    int newHeight = _pixmap.height()*110/100;

    QPixmap newPixmap = _pixmap.scaled(newWidth, newHeight);

    ui->label->setPixmap(newPixmap);

    _pixmap = newPixmap;
}

void MainWindow::on_actionZoom_Indietro_triggered()
{
    if(_pixmap.width() == 0 || _pixmap.height() == 0)
    {
        QMessageBox::warning(this, tr("Attenzione"), tr("Non è stata selezionata alcuna immagine adatta alla zoom"));
        return;
    }

    int newWidth = _pixmap.width()*90/100;
    int newHeight = _pixmap.height()*90/100;

    QPixmap newPixmap = _pixmap.scaled(newWidth, newHeight);

    ui->label->setPixmap(newPixmap);

    _pixmap = newPixmap;
}

void MainWindow::on_actionZoom_1_1_triggered()
{
    if(_pixmap.width() == 0 || _pixmap.height() == 0)
    {
        QMessageBox::warning(this, tr("Attenzione"), tr("Non è stata selezionata alcuna immagine adatta alla zoom"));
        return;
    }

    QPixmap restoredPixmap = _pixmap.scaled(_originalWidth, _originalHeight);

    ui->label->setPixmap(restoredPixmap);

    _pixmap = restoredPixmap;
}

void MainWindow::on_actionStart_triggered()
{
    if(_movie == nullptr)
    {
        QMessageBox::warning(this, tr("Attenzione"), tr("Non è stata selezionata alcuna gif"));
        return;
    }

    _movie->start();

}

void MainWindow::on_actionStop_triggered()
{
    if(_movie == nullptr)
    {
        QMessageBox::warning(this, tr("Attenzione"), tr("Non è stata selezionata alcuna gif"));
        return;
    }

    _movie->stop();
}

void MainWindow::on_actionPausa_triggered(bool checked)
{
    if(_movie == nullptr)
    {
        QMessageBox::warning(this, tr("Attenzione"), tr("Non è stata selezionata alcuna gif"));
        return;
    }

    if(checked)
    {
        _movie->setPaused(true);
    }
    else
    {
        _movie->setPaused(false);
    }


}

void MainWindow::on_actionAumenta_triggered()
{
    if(_movie == nullptr)
    {
        QMessageBox::warning(this, tr("Attenzione"), tr("Non è stata selezionata alcuna gif"));
        return;
    }

    _movie->setSpeed(120);
}

void MainWindow::on_actionDiminuisci_triggered()
{
    if(_movie == nullptr)
    {
        QMessageBox::warning(this, tr("Attenzione"), tr("Non è stata selezionata alcuna gif"));
        return;
    }

    _movie->setSpeed(80);
}

void MainWindow::on_actionNormale_triggered()
{
    if(_movie == nullptr)
    {
        QMessageBox::warning(this, tr("Attenzione"), tr("Non è stata selezionata alcuna gif"));
        return;
    }

    _movie->setSpeed(100);
}
